import streamlit as st
import pickle
import pandas as pd
import requests

st.set_page_config(                     #DESIGN CODE
    layout="wide",
    initial_sidebar_state="expanded"
)

hide_menu_style = """                   
    <style>
    #MainMenu {visibility: hidden; }
    footer {visibility: hidden; }
    </style>
    """                                 #DESIGN CODE
st.markdown(hide_menu_style, unsafe_allow_html=True)


def fetch_poster(movie_id):            # THIS FUNCTION FETCH POSTER FROM TMDB API BY USING MOVIE ID.
    response = requests.get(
        'https://api.themoviedb.org/3/movie/{}?api_key=f784ca125c814e99ee9dc86e543ba526&language=en-US'.format(
            movie_id))
    data = response.json()
    return "https://image.tmdb.org/t/p/w500/" + data['poster_path']


def recommend(movie):                # THIS FUNCTION TAKE VECTOR OF MOVIES THAT IS STORED IN SIMILARITY AND PASS THEIR NAMES.
    movie_index = movies[movies['title'] == movie].index[0]
    distances = similarity[movie_index]
    movies_list = sorted(list(enumerate(distances)), reverse=True, key=lambda x: x[1])[1:6]

    st.balloons()
    st.success('Similar movies you may like :')

    recommended_movies = []
    recommended_movies_posters = []

    for i in movies_list:            # THIS FUNCTION RETURNS SIMILAR MOVIES TO THE MOVIE ID WHICH IS STORED IN MOVIE FUNCTION.
        movie_id = movies.iloc[i[0]].movie_id
        recommended_movies.append(movies.iloc[i[0]].title)
        recommended_movies_posters.append(fetch_poster(movie_id))
    return recommended_movies, recommended_movies_posters


Dict = pickle.load(
    open('movies_dict.pkl', 'rb'))   # HERE WE ADDED THE MOVIES DICTIONARY WHICH MADE IN JUPYTER NOTEBOOK TO DICT
movies = pd.DataFrame(Dict)          # HERE WE MADE A DATA FRAME AND PASSED THE VALUE OF DICT IN IT.

similarity = pickle.load(open('similarity.pkl', 'rb'))

st.title("Get Movie Recommendations")
selected_movie_name = st.selectbox(  # THIS FUNCTION IS USED TO ADD A SELECT BOX TO THE LOCAL HOST.
    'Search here for results',
    movies['title'].values)          # HERE WE SHOWED THE TITLE IN THE SELECT BOX.

if st.button('Recommend'):
    names, posters = recommend(selected_movie_name)

    col1, col2, col3, col4, col5 = st.columns(5)  # THIS FUNCTION SHOWS MOVIE NAME AND POST.

    with col1:
        st.text(names[0])
        st.image(posters[0])

    with col2:
        st.text(names[1])
        st.image(posters[1])

    with col3:
        st.text(names[2])
        st.image(posters[2])

    with col4:
        st.text(names[3])
        st.image(posters[3])

    with col5:
        st.text(names[4])
        st.image(posters[4])
